// 婕旂ず鐢ㄧ涓夋柟鎻掍欢锛氳窡绀惧尯鎻掍欢鍚屼竴涓舰鐘讹紙cordis 鍛藉悕瀵煎嚭 name/inject/apply锛?// 宸ュ叿鐢?dsh 鐨?defineTool 娉ㄥ唽锛夈€傚畠璺戝湪鐪?Node 閲岋紝涓嶇粡杩?QuickJS銆?//
// 涓変釜宸ュ叿鍒绘剰瑕嗙洊涓夋潯閾撅細
//   hello_probe 鈥斺€?姝ｅ父杩斿洖鍊硷紙楠岃瘉 hello/tool.invoke/render/鏂囨湰鍥炰紶锛?//   hello_fail  鈥斺€?鎶涘紓甯革紙楠岃瘉妗ユ妸閿欒杞垚 {ok:false}锛屼笉绌块€忓涓伙級
//   hello_slow  鈥斺€?鐫″緢涔咃紙楠岃瘉鍘熺敓渚ц秴鏃?+ 鍙栨秷涓嶇剨姝诲涓伙級
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'hello-plugin'
export const inject = ['tools', 'systemPrompt']

export function apply(ctx) {
  // 往系统提示里加一段（原生侧每次请求前拉一次，验证 prompt.assemble 这条链）。
  ctx.systemPrompt.section({
    name: 'hello-plugin/greeting',
    order: 500,
    text: '演示段（来自 Node 插件 hello-plugin）：回答里可以带一句 hello from node plugin 作为标记。',
  })

  ctx.tools.register(
    defineTool({
      name: 'hello_probe',
      description: 'Echo a note back from a third-party Node plugin running inside the app.',
      parameters: {
        note: {
          type: 'string',
          description: 'Optional note to echo back unchanged.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            greeting: { type: 'string', required: true },
            note: { type: 'string' },
            uptimeMs: { type: 'integer', required: true },
          },
        },
        render: (_args, value) => [
          { type: 'text', text: `${value.greeting} (uptime ${value.uptimeMs}ms, note=${value.note ?? 'none'})` },
        ],
      },
      execute(args) {
        return Promise.resolve({
          greeting: 'hello from node plugin host',
          note: typeof args?.note === 'string' ? args.note : undefined,
          uptimeMs: Math.round(process.uptime() * 1000),
        })
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'hello_fail',
      description: 'Always throws, to prove plugin errors travel back as structured failures.',
      parameters: {
        reason: { type: 'string', description: 'Message to put in the error.' },
      },
      output: {
        schema: { type: 'object', additionalProperties: false, properties: { ok: { type: 'boolean', required: true } } },
        render: () => [{ type: 'text', text: 'unreachable' }],
      },
      execute(args) {
        return Promise.reject(new Error(`hello_fail: ${args?.reason ?? 'no reason given'}`))
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'hello_slow',
      description: 'Sleeps for the requested number of milliseconds, to exercise timeouts.',
      parameters: {
        ms: { type: 'integer', required: true, description: 'How long to sleep.' },
      },
      output: {
        schema: { type: 'object', additionalProperties: false, properties: { sleptMs: { type: 'integer', required: true } } },
        render: (_args, value) => [{ type: 'text', text: `slept ${value.sleptMs}ms` }],
      },
      async execute(args) {
        const ms = Math.max(0, Math.min(Number(args?.ms ?? 0), 300000))
        await new Promise((resolve) => setTimeout(resolve, ms))
        return { sleptMs: ms }
      },
    }),
  )
}
