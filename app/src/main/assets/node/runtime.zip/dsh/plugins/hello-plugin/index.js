// 演示用第三方插件：跟社区插件同一个形状（cordis 命名导出 name/inject/apply；
// 工具用 dsh 的 defineTool 注册）。它跑在真 Node 里，不经过 QuickJS。
//
// 三个工具刻意覆盖三条链：
//   hello_probe —— 正常返回值（验证 hello/tool.invoke/render/文本回传）
//   hello_fail   —— 抛异常（验证桥把错误转成 {ok:false}，不空透宿主）
//   hello_slow   —— 睡很久（验证原生侧超时 + 取消不焊死宿主）
//
// P3 追加（docs/187 §9.2）：
//   ctx.llm.register      —— 两条演示供应商：一条只声明（原生走自己的 HTTP 通道，真流式），
//                            一条只有 JS stream() 回调（原生调不到 → 必须如实标不可用）；
//   ctx.commands.register —— 两条演示斜杠命令：/hello-node（成功）与 /hello-node-fail（error 结果）。
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'hello-plugin'
export const inject = ['tools', 'systemPrompt', 'llm', 'commands']

export function apply(ctx) {
  // 往系统提示里加一段（原生侧每次请求前拉一次，验证 prompt.assemble 这条链）。
  ctx.systemPrompt.section({
    name: 'hello-plugin/greeting',
    order: 500,
    text: '演示段（来自 Node 插件 hello-plugin）：回答里可以带一句 hello from node plugin 作为标记。',
  })

  // P3-b：声明式供应商（只给 id/label，端点/模型/key 全部跟随宿主）——
  // 原生会把它注册成一个 ConfiguredLlmProvider，是真流式（原生自己的 SSE 通道）。
  ctx.llm.register({
    id: 'hello-node-follow',
    label: 'Node 演示 · 跟随宿主端点',
    protocol: 'openai',
  })

  // P3-b：只有 JS stream() 回调的供应商。原生桥接不到这个函数，所以它必须显示成
  // 「不可用（仅回调）」，不能假装可用 —— 这条就是用来验「如实标注」的。
  ctx.llm.register({
    id: 'hello-node-callback',
    label: 'Node 演示 · 仅 JS 流回调',
    stream: async function* () {
      yield 'unreachable: native cannot call a node stream() callback'
    },
  })

  // P3-c：两条斜杠命令（handler 返回 {kind,text}，原生落审计后用 command notice 显示）。
  ctx.commands.register({
    name: 'hello-node',
    description: 'Node 插件演示命令：回显 rawInput 与命令 id',
    input: { hint: '任意文本' },
    handler(invocation) {
      const echo = invocation?.rawInput ?? ''
      return {
        kind: 'success',
        text: `hello from node command (id=${invocation?.commandId ?? '?'}, raw=${echo.trim() || '空'})`,
      }
    },
  })

  ctx.commands.register({
    name: 'hello-node-fail',
    description: 'Node 插件演示命令：总是返回错误结果',
    handler() {
      return { kind: 'error', text: 'hello-node-fail: 这是预期的失败（验证 command/error 回传）' }
    },
  })

  ctx.tools.register(
    defineTool({
      name: 'hello_probe',
      description: 'Echo a note back from a third-party Node plugin running inside the app.',
      parameters: {
        note: {
          type: 'string',
          description: 'Optional note to echo back unchanged.',
        },
      },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: {
            greeting: { type: 'string', required: true },
            note: { type: 'string' },
            uptimeMs: { type: 'integer', required: true },
          },
        },
        render: (_args, value) => [
          { type: 'text', text: `${value.greeting} (uptime ${value.uptimeMs}ms, note=${value.note ?? 'none'})` },
        ],
      },
      execute(args) {
        return Promise.resolve({
          greeting: 'hello from node plugin host',
          note: typeof args?.note === 'string' ? args.note : undefined,
          uptimeMs: Math.round(process.uptime() * 1000),
        })
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'hello_fail',
      description: 'Always throws, to prove plugin errors travel back as structured failures.',
      parameters: {
        reason: { type: 'string', description: 'Message to put in the error.' },
      },
      output: {
        schema: { type: 'object', additionalProperties: false, properties: { ok: { type: 'boolean', required: true } } },
        render: () => [{ type: 'text', text: 'unreachable' }],
      },
      execute(args) {
        return Promise.reject(new Error(`hello_fail: ${args?.reason ?? 'no reason given'}`))
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'hello_slow',
      description: 'Sleeps for the requested number of milliseconds, to exercise timeouts.',
      parameters: {
        ms: { type: 'integer', required: true, description: 'How long to sleep.' },
      },
      output: {
        schema: { type: 'object', additionalProperties: false, properties: { sleptMs: { type: 'integer', required: true } } },
        render: (_args, value) => [{ type: 'text', text: `slept ${value.sleptMs}ms` }],
      },
      async execute(args) {
        const ms = Math.max(0, Math.min(Number(args?.ms ?? 0), 300000))
        await new Promise((resolve) => setTimeout(resolve, ms))
        return { sleptMs: ms }
      },
    }),
  )
}
