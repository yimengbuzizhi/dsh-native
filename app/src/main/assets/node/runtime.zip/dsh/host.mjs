// 鲸歌 Node 插件宿主（docs/185 P2）。
//
// 职责只有三件：
//   1. 起一个真 cordis Context，装上 dsh 内核里的工具/提示词/会话投影服务；
//   2. 按 node-host-plugins.json 逐个装载插件（npm 包原样，零补丁），把 ctx.tools 里
//      注册出来的工具整理成清单；
//   3. 开一个只绑 127.0.0.1 的回环 WS，让原生侧 hello / tool.invoke / host.stop。
//
// 刻意不做的事：不起 turn engine、不起 agent loop、不读会话文件、不写 session.v4。
// 原生侧是唯一真相：工具调用先过原生审批与审计，再落到这里执行。
import { createServer } from 'node:http'
import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { Context } from '@deepseek-ai/cordis'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import Projections from '@deepseek-ai/dsh-session-projection'
import { WebSocketServer } from 'ws'

const here = dirname(fileURLToPath(import.meta.url))
const processStart = Date.now() - Math.round(process.uptime() * 1000)

const LOG_CAP = 200
const SESSION_EVENT_CAP = 2000
const logs = []
const clients = new Set()

/** 任何值 → 有界字符串（日志/错误都走这里，避免插件把超长对象灌进管道）。 */
function safeText(value, limit = 4000) {
  let text
  if (typeof value === 'string') text = value
  else if (value instanceof Error) text = value.stack || value.message
  else {
    try {
      text = JSON.stringify(value)
    } catch {
      text = String(value)
    }
  }
  if (typeof text !== 'string') text = String(text)
  return text.length > limit ? `${text.slice(0, limit)}…` : text
}

function pushLog(level, text) {
  const entry = { level, text: safeText(text), at: Date.now() }
  logs.push(entry)
  if (logs.length > LOG_CAP) logs.shift()
  const frame = JSON.stringify({ op: 'host.log', ...entry })
  for (const ws of clients) {
    try {
      ws.send(frame)
    } catch {
      // 客户端断开的瞬间写失败是正常的，下一次广播会自然剔除
    }
  }
  return entry
}

// console.* 全部进 host.log 通道（原生侧插件页可看），stdout 仍然保留一份给 adb logcat。
for (const level of ['log', 'info', 'warn', 'error']) {
  const original = console[level].bind(console)
  console[level] = (...args) => {
    pushLog(level === 'error' || level === 'warn' ? level : 'info', args.map((arg) => safeText(arg)).join(' '))
    original(...args)
  }
}

process.on('uncaughtException', (error) => {
  // 一个插件里的异步炸弹不该让宿主静默消失：记下来，继续服务其它工具。
  pushLog('error', `uncaughtException: ${safeText(error)}`)
})
process.on('unhandledRejection', (reason) => {
  pushLog('error', `unhandledRejection: ${safeText(reason)}`)
})

/** 读插件清单：{ plugins: [{ module, config }] }，缺文件 = 只装内核。 */
async function readPluginList() {
  const path = join(here, 'node-host-plugins.json')
  if (!existsSync(path)) return []
  const parsed = JSON.parse(await readFile(path, 'utf8'))
  return Array.isArray(parsed?.plugins) ? parsed.plugins.filter(Boolean) : []
}

const ctx = new Context()
await ctx.plugin(SystemPrompt)
await ctx.plugin(ToolRuntime)
await ctx.plugin(Projections)

const loadedPlugins = []
// 插件注册的提示词段/上下文：同样用「加载前后差集」认领，避免把 dsh 自己的
// harness 段（身份/persona）也端给原生侧 —— 那部分原生有自己的拼装。
const ownedSectionNames = new Set()
const ownedContextNames = new Set()
const registeredNames = (pick) =>
  new Set(ctx.systemPrompt.layers.merge(undefined, pick).keys())
for (const entry of await readPluginList()) {
  const specifier = typeof entry?.module === 'string' ? entry.module : ''
  if (!specifier) continue
  const target =
    specifier.startsWith('.') || specifier.startsWith('/')
      ? pathToFileURL(resolve(here, specifier)).href
      : specifier
  // 工具归属：插件加载前后对比 tools.schemas()，差集就是这个插件注册的工具。
  const before = new Set(ctx.tools.schemas().map((schema) => schema.name))
  const beforeSections = registeredNames((layer) => layer.sections)
  const beforeContexts = registeredNames((layer) => layer.contexts)
  try {
    const mod = await import(target)
    await ctx.plugin(mod, entry.config ?? {})
    const added = ctx.tools.schemas().map((schema) => schema.name).filter((name) => !before.has(name))
    for (const name of registeredNames((layer) => layer.sections)) {
      if (!beforeSections.has(name)) ownedSectionNames.add(name)
    }
    for (const name of registeredNames((layer) => layer.contexts)) {
      if (!beforeContexts.has(name)) ownedContextNames.add(name)
    }
    loadedPlugins.push({ module: specifier, ok: true, tools: added })
  } catch (error) {
    loadedPlugins.push({ module: specifier, ok: false, error: safeText(error, 800), tools: [] })
    pushLog('error', `plugin load failed: ${specifier}: ${safeText(error, 800)}`)
  }
}

const sessionEvents = []

/** 一次调用的最小 agent 门面：插件只会 append 事件，宿主不落盘、不重放。 */
function newAgent() {
  return {
    session: {
      append(type, data) {
        sessionEvents.push([type, data])
        if (sessionEvents.length > SESSION_EVENT_CAP) sessionEvents.shift()
      },
    },
  }
}

/** 模型可用的工具清单（只带 name/description/parameters，跟 tools.schemas() 同口径）。 */
function manifest() {
  const schemas = ctx.tools.schemas()
  return schemas.map((schema) => ({
    name: schema.name,
    description: schema.description ?? '',
    parameters: schema.parameters ?? { type: 'object', properties: {} },
  }))
}

/** 插件自己声明的渲染函数优先；没声明就退回 JSON 文本。 */
function renderResult(definition, args, value) {
  try {
    const blocks = definition.output?.render?.(args, value)
    if (Array.isArray(blocks)) {
      const text = blocks
        .filter((block) => block?.type === 'text' && typeof block.text === 'string')
        .map((block) => block.text)
        .join('\n')
      if (text) return text
    }
  } catch (error) {
    pushLog('warn', `render failed for ${definition.name}: ${safeText(error, 400)}`)
  }
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}

async function invokeTool(msg) {
  const name = String(msg?.name ?? '')
  // executable() 才认条件注册；拿不到再退回 get()，避免把已注册工具误判成不存在。
  const definition = ctx.tools.executable(name) ?? ctx.tools.get(name)
  if (!definition) return { ok: false, error: `unknown tool: ${name}`, ms: 0 }
  const args = msg?.args ?? {}
  const timeoutMs = Number.isFinite(msg?.timeoutMs)
    ? Math.max(1000, Math.min(Number(msg.timeoutMs), 600000))
    : 60000
  const controller = new AbortController()
  let timer
  const started = Date.now()
  try {
    // 超时用 race 兑现：工具自己不理会 signal 时，调用方也必须按时拿到失败，
    // 而不是等它睡完（插件里的死循环/长 IO 不能把原生侧的审批流程焊住）。
    const value = await Promise.race([
      definition.execute(args, { agent: newAgent(), signal: controller.signal }),
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          controller.abort()
          reject(new Error(`tool timed out after ${timeoutMs}ms`))
        }, timeoutMs)
      }),
    ])
    return { ok: true, value, text: renderResult(definition, args, value), ms: Date.now() - started }
  } catch (error) {
    const aborted = controller.signal.aborted
    return {
      ok: false,
      error: aborted ? `tool timed out after ${timeoutMs}ms` : safeText(error, 2000),
      ms: Date.now() - started,
    }
  } finally {
    clearTimeout(timer)
  }
}

/**
 * 插件往系统提示里注册的段/上下文（`ctx.systemPrompt.section` / `.context`）。
 * 原生侧每次发起请求前拉一次，塞进 PromptPack 的拼装里 —— 段文本里的 `{{变量}}`
 * 由原生侧统一替换（和原生插件同一套口径）。
 *
 * 优先走内核的 `systemPrompt.assemble()`；但组装会向工具执行器要一段工具说明，
 * 而这个宿主没有装执行器（工具是原生侧直接调 `tool.invoke` 执行的，不经过 dsh
 * 的执行器），于是退化成**只读**地合并各作用域已注册的段 —— 不注册假服务、不改
 * 上游代码，只是把插件已经登记进去的东西读出来。
 */
async function assemblePrompt() {
  const service = ctx.systemPrompt
  const resolve = (value) => (typeof value === 'function' ? value({}) : value)
  const text = (value) => (typeof value === 'string' ? value : '')
  /** 只认领插件自己注册的段；dsh 的 harness 段由原生自己的拼装负责。 */
  const owned = (list, names) => list.filter((item) => names.has(item.name))
  try {
    const assembly = await service.assemble()
    return {
      source: 'assemble',
      sections: owned(
        (assembly?.sections ?? []).map((section) => ({
          name: section.name,
          text: text(section.text),
          interpolate: section.interpolate !== false,
        })),
        ownedSectionNames,
      ),
      contexts: owned(
        (assembly?.contexts ?? []).map((context) => ({
          name: context.name,
          text: text(context.text),
          interpolate: context.interpolate !== false,
        })),
        ownedContextNames,
      ),
      variables: Object.fromEntries(
        Object.entries(assembly?.variables ?? {}).filter(([, value]) => typeof value === 'string'),
      ),
    }
  } catch (error) {
    pushLog('warn', `prompt assemble fell back to registry read: ${safeText(error, 300)}`)
  }
  const mergedSections = service.layers.merge(undefined, (layer) => layer.sections)
  const mergedContexts = service.layers.merge(undefined, (layer) => layer.contexts)
  const sections = [...mergedSections.values()]
    .map((section) => ({
      name: section.name,
      order: Number.isFinite(section.order) ? section.order : 0,
      text: text(resolve(section.text)),
      interpolate: section.interpolate !== false,
    }))
    .filter((section) => ownedSectionNames.has(section.name))
    .sort((a, b) => a.order - b.order || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    .map(({ order, ...rest }) => rest)
  const contexts = [...mergedContexts.values()]
    .map((context) => ({
      name: context.name,
      order: Number.isFinite(context.order) ? context.order : 0,
      text: text(resolve(context.text)),
      interpolate: context.interpolate !== false,
    }))
    .filter((context) => ownedContextNames.has(context.name))
    .sort((a, b) => a.order - b.order || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    .map(({ order, ...rest }) => rest)
  return { source: 'registry', sections, contexts, variables: {} }
}

function helloFrame() {
  return {
    op: 'host.hello',
    pid: process.pid,
    version: process.version,
    bootMs: Date.now() - processStart,
    headless: true,
    tools: manifest(),
    plugins: loadedPlugins,
    logs: logs.slice(-40),
  }
}

const server = createServer((req, res) => {
  res.statusCode = 404
  res.end('not found')
})

const wss = new WebSocketServer({ server })

wss.on('connection', (ws) => {
  clients.add(ws)
  ws.send(JSON.stringify(helloFrame()))
  ws.on('close', () => clients.delete(ws))
  ws.on('message', async (raw) => {
    let msg
    try {
      msg = JSON.parse(raw.toString())
    } catch {
      return
    }
    if (msg?.op === 'tool.invoke') {
      const result = await invokeTool(msg)
      const frame = {
        op: 'tool.result',
        id: msg.id,
        ok: result.ok,
        value: result.value,
        text: result.text,
        error: result.error,
        ms: result.ms,
        sessionEvents: sessionEvents.length,
      }
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(frame))
    } else if (msg?.op === 'prompt.assemble') {
      try {
        const payload = await assemblePrompt()
        if (ws.readyState === ws.OPEN) {
          ws.send(JSON.stringify({ op: 'prompt.result', id: msg.id, ok: true, ...payload }))
        }
      } catch (error) {
        if (ws.readyState === ws.OPEN) {
          ws.send(
            JSON.stringify({ op: 'prompt.result', id: msg.id, ok: false, error: safeText(error, 800) }),
          )
        }
      }
    } else if (msg?.op === 'host.manifest') {
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ op: 'host.manifest', id: msg.id, tools: manifest(), plugins: loadedPlugins }))
    } else if (msg?.op === 'host.ping') {
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ op: 'host.pong', id: msg.id, at: Date.now() }))
    } else if (msg?.op === 'host.stop') {
      if (ws.readyState === ws.OPEN) {
        // 先 ack 再退：原生侧要能确认「它收到停止指令了」，而不是靠进程随机消失。
        ws.send(JSON.stringify({ op: 'host.ack', id: msg.id, at: Date.now() }))
        ws.send(JSON.stringify({ op: 'host.bye', at: Date.now() }))
      }
      ws.close()
      server.close()
      setTimeout(() => process.exit(0), 30)
    }
  })
})

server.listen(0, '127.0.0.1', () => {
  const bootMs = Date.now() - processStart
  // 原生侧只认这一行：端口必须由内核分配后回传，禁写死。
  console.log(`HOST_READY ${server.address().port} ${bootMs}`)
})
