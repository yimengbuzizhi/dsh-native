// 鲸歌 Node 插件宿主（docs/185 P2 / docs/187 §九）。
//
// 职责只有三件：
//   1. 起一个真 cordis Context，装上 dsh 内核里的工具/提示词/会话投影服务；
//   2. 按 data/node-host-plugins.json 逐个装载插件（npm 包原样，零补丁），把 ctx.tools 里
//      注册出来的工具整理成清单；
//   3. 开一个只绑 127.0.0.1 的回环 WS，让原生侧 hello / tool.invoke / tool.cancel / host.stop。
//
// 刻意不做的事：不起 turn engine、不起 agent loop、不读会话文件、不写 session.v4。
// 原生侧是唯一真相：工具调用先过原生审批与审计，再落到这里执行。
import { createServer } from 'node:http'
import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { timingSafeEqual } from 'node:crypto'
import { Context } from '@deepseek-ai/cordis'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import Projections from '@deepseek-ai/dsh-session-projection'
import { WebSocketServer } from 'ws'

const here = dirname(fileURLToPath(import.meta.url))
// 运行时在 files/node/runtime/<version>/dsh/；用户插件/清单在 files/node/data/。
// 升级运行时只换前者，所以 dataDir 必须由原生侧显式传进来，不能默认跟着 here 走。
const dataDir = process.env.DSH_NODE_DATA ? resolve(process.env.DSH_NODE_DATA) : here
const processStart = Date.now() - Math.round(process.uptime() * 1000)

// docs/187 §九 第 2 项：WS 鉴权。native 每次 spawn 生成 32B 随机 token（64 hex），
// 只经环境变量传进来；没有 token 直接拒绝启动（不允许裸开回环端口）。
const expectedToken = process.env.DSH_NODE_TOKEN ?? ''
if (expectedToken.length < 32) {
  process.stderr.write('HOST_FATAL DSH_NODE_TOKEN missing or too short; refusing to listen\n')
  process.exit(1)
}

const LOG_CAP = 200
const SESSION_EVENT_CAP = 2000
const logs = []
const clients = new Set()

/** 任何值 → 有界字符串（日志/错误都走这里，避免插件把超长对象灌进管道）。 */
function safeText(value, limit = 4000) {
  let text
  if (typeof value === 'string') text = value
  else if (value instanceof Error) text = value.stack || value.message
  else {
    try {
      text = JSON.stringify(value)
    } catch {
      text = String(value)
    }
  }
  if (typeof text !== 'string') text = String(text)
  return text.length > limit ? `${text.slice(0, limit)}…` : text
}

function pushLog(level, text) {
  const entry = { level, text: safeText(text), at: Date.now() }
  logs.push(entry)
  if (logs.length > LOG_CAP) logs.shift()
  const frame = JSON.stringify({ op: 'host.log', ...entry })
  for (const ws of clients) {
    try {
      ws.send(frame)
    } catch {
      // 客户端断开的瞬间写失败是正常的，下一次广播会自然剔除
    }
  }
  return entry
}

// console.* 全部进 host.log 通道（原生侧插件页可看），stdout 仍然保留一份给 adb logcat。
for (const level of ['log', 'info', 'warn', 'error']) {
  const original = console[level].bind(console)
  console[level] = (...args) => {
    pushLog(level === 'error' || level === 'warn' ? level : 'info', args.map((arg) => safeText(arg)).join(' '))
    original(...args)
  }
}

process.on('uncaughtException', (error) => {
  // docs/187 §九 第 10 项：不再吞异常带病运行——记录后 exit(1)，由 native supervisor 重启
  // （5 分钟内 3 次则进 Failed，不再无限重启）。这里不做任何「继续服务」的恢复动作。
  const text = `uncaughtException: ${safeText(error)}`
  pushLog('error', text)
  try {
    process.stderr.write(`${text}\n`)
  } catch {
    // stderr 也坏掉时只能退化成 host.log，仍然退出
  }
  // 给 stdout/stderr 一点落地时间，再退出。
  setTimeout(() => process.exit(1), 25)
})
process.on('unhandledRejection', (reason) => {
  // 未处理的 Promise 只记录：它不是同步异常，不能据此断定宿主状态已坏。
  pushLog('error', `unhandledRejection: ${safeText(reason)}`)
})

/** 读插件清单：{ plugins: [{ module, config }] }，缺文件 = 只装内核。 */
async function readPluginList() {
  const path = join(dataDir, 'node-host-plugins.json')
  if (!existsSync(path)) return []
  const parsed = JSON.parse(await readFile(path, 'utf8'))
  return Array.isArray(parsed?.plugins) ? parsed.plugins.filter(Boolean) : []
}

const ctx = new Context()
await ctx.plugin(SystemPrompt)
await ctx.plugin(ToolRuntime)
await ctx.plugin(Projections)

// ---------------------------------------------------------------------------
// P3-b：`ctx.llm.register` —— 模型供应商登记（只登记，不代理流式）
//
// 手机端没有能把 JS 的 `stream()` 回调拉进原生请求链的通道，所以这里只把插件**声明**的
// provider（id / label / 协议 / baseUrl / model / key）原样报给原生；真正发请求的是原生
// `ConfiguredLlmProvider`（走内置的 Anthropic / OpenAI 两条 HTTP 通道）。
//
// 因此「支持流式」必须如实分层：
// - `streamMode: 'http'`     —— 插件只给了声明，原生用自己的 HTTP/SSE 通道，是真流式；
// - `streamMode: 'callback'` —— 插件给了 `stream()` 函数；**原生调不到它**，这一项标不可用；
// - `streamMode: 'http+callback'` —— 两者都有，原生只走 HTTP 那一半，callback 不会被执行。
// 绝不把 callback-only 的 provider 假装成可用（docs/187 §9.2「不要假装流式」）。
// ---------------------------------------------------------------------------

/** 加载中的插件模块（用来给注册项打 owner；宿主重启才重新加载，不做热卸载）。 */
let loadingOwner = ''

const llmEntries = new Map()

function bounded(value, limit = 300) {
  const text = typeof value === 'string' ? value : value == null ? '' : String(value)
  return text.length > limit ? `${text.slice(0, limit)}…` : text
}

/** 协议归一：只认原生那两条通道；空 = 跟随宿主当前协议。 */
function normalizeProtocol(value) {
  const text = bounded(value, 40).trim().toLowerCase()
  if (!text) return ''
  if (text.includes('openai') || text.includes('chat/completions') || text.includes('chat_completions')) return 'openai'
  if (text.includes('anthropic') || text.includes('messages') || text.includes('claude')) return 'anthropic'
  return ''
}

/** 插件 provider 声明 → 原生可消费的一条（字段名兼容几种写法，绝不猜 key）。 */
function describeLlmProvider(raw, owner) {
  if (!raw || typeof raw !== 'object') return null
  const id = bounded(raw.id ?? raw.provider ?? raw.providerId ?? raw.name, 120).trim()
  if (!id) return null
  const hasCallback = typeof raw.stream === 'function'
  const baseUrl = bounded(raw.baseUrl ?? raw.baseURL ?? raw.endpoint ?? raw.apiBase ?? raw.url, 600).trim()
  const model = bounded(raw.model ?? raw.defaultModel ?? raw.modelId, 200).trim()
  const apiKey = bounded(raw.apiKey ?? raw.key ?? raw.token, 600).trim()
  const declared = baseUrl !== '' || model !== '' || apiKey !== ''
  const streamMode = hasCallback ? (declared ? 'http+callback' : 'callback') : 'http'
  const usable = streamMode !== 'callback'
  const reason = usable
    ? (declared
      ? ''
      : '插件只声明了 id/label：请求会跟随宿主当前端点与 key')
    : '插件只提供 JS stream() 回调，原生桥接不到（不假装流式）'
  return {
    id,
    label: bounded(raw.label ?? raw.displayName ?? raw.name ?? id, 160).trim() || id,
    protocol: normalizeProtocol(raw.protocol ?? raw.api ?? raw.kind ?? raw.wire),
    baseUrl,
    model,
    apiKey,
    hasStreamCallback: hasCallback,
    streamMode,
    usable,
    reason,
    owner: owner || '',
  }
}

/** 注册一条供应商；同 id 后注册覆盖（与原生 `LlmProviders.register` 同语义）。 */
function registerLlmProvider(raw, owner = loadingOwner) {
  const entry = describeLlmProvider(raw, owner)
  if (!entry) {
    pushLog('warn', `llm.register ignored: provider needs a non-empty id (${safeText(raw, 200)})`)
    return () => {}
  }
  const previous = llmEntries.get(entry.id)
  if (previous && previous.owner && previous.owner !== entry.owner) {
    pushLog('warn', `llm.register overrides provider ${entry.id}: ${previous.owner} -> ${entry.owner || '?'}`)
  }
  llmEntries.set(entry.id, entry)
  pushLog(
    entry.usable ? 'info' : 'warn',
    `llm.register id=${entry.id} protocol=${entry.protocol || 'host'} model=${entry.model || 'host'} ` +
      `baseUrl=${entry.baseUrl ? 'plugin' : 'host'} key=${entry.apiKey ? 'plugin' : 'host'} ` +
      `stream=${entry.streamMode} usable=${entry.usable} owner=${entry.owner || '?'}`,
  )
  return () => {
    if (llmEntries.get(entry.id) === entry) llmEntries.delete(entry.id)
  }
}

const llmService = {
  /** P3-b 的声明式入口（本宿主扩展；原生据此新增一个 ConfiguredLlmProvider）。 */
  register(descriptor) {
    return registerLlmProvider(descriptor)
  },
  unregister(id) {
    const key = String(id ?? '')
    const existed = llmEntries.delete(key)
    if (existed) pushLog('info', `llm.unregister id=${key}`)
    return existed
  },
  /** 给原生/调试看的完整描述（含 streamMode / usable / reason）。 */
  list() {
    return [...llmEntries.values()].map((entry) => ({ ...entry }))
  },
  /** dsh `llm.listProviders()` 的形状（只 id/name）。 */
  listProviders() {
    return [...llmEntries.values()].map((entry) => ({ id: entry.id, name: entry.label }))
  },
  get(id) {
    const entry = llmEntries.get(String(id ?? ''))
    return entry ? { ...entry } : undefined
  },
  /**
   * dsh 真 API：`registerAdapter(providers, adapter)`。适配器的流式实现是 JS 对象，
   * 原生拿不到 → 如实登记成 callback-only（可用性 false），不写假服务。
   */
  registerAdapter(providers, adapter) {
    const names = Array.isArray(providers) ? providers.map((item) => String(item ?? '')) : []
    const disposers = []
    const register = (routes) => {
      for (const route of routes) {
        const info = (() => {
          try {
            return adapter?.providerInfo?.(route) ?? {}
          } catch {
            return {}
          }
        })()
        disposers.push(
          registerLlmProvider(
            {
              id: String(info.id ?? route),
              label: String(info.name ?? info.id ?? route),
              stream: () => {},
            },
            loadingOwner,
          ),
        )
      }
    }
    register(names)
    const handle = () => {
      while (disposers.length) disposers.pop()()
    }
    handle.replace = (next) => {
      while (disposers.length) disposers.pop()()
      register(Array.isArray(next) ? next.map((item) => String(item ?? '')) : [])
    }
    return handle
  },
  /** dsh 真 API：可配置供应商目录。目录只影响桌面端设置页，原生用不到 → 只记账。 */
  registerConfigurableProviders(entries) {
    const list = Array.isArray(entries) ? entries : []
    for (const entry of list) {
      pushLog('warn', `llm.registerConfigurableProviders ignored on native: ${bounded(entry?.provider ?? '?', 80)}`)
    }
    const handle = () => {}
    handle.replace = () => {}
    return handle
  },
}
ctx.provide('llm', llmService)

// ---------------------------------------------------------------------------
// P3-c：`ctx.commands.register` —— 人类斜杠命令
//
// 语义按上游 `docs/subsystems/commands.md`：定义 = {name, description, input?, handler}；
// `execute()` 返回 `{commandId, result:{kind:'success'|'error', text}}`，语法/名字解析不到
// 时返回 undefined（原生据此显示「未注册」而不是静默）。
// 这里的实现不碰会话文件、不写 session.v4：只把 handler 的返回值交回原生，由原生落审计。
// ---------------------------------------------------------------------------

const commandEntries = new Map()
let commandSeq = 0

/** 上游 `parseCommand()` 的同形实现（`/name` + 一个分隔空白）。 */
function parseCommandText(line) {
  const text = typeof line === 'string' ? line : ''
  if (!text.startsWith('/')) return null
  if (text.length < 2) return null
  const first = text[1]
  if (!(first >= 'a' && first <= 'z')) return null
  let index = 2
  while (index < text.length) {
    const ch = text[index]
    const ok = (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch === '_' || ch === '-'
    if (!ok) break
    index += 1
  }
  if (index < text.length && !/[\t\n\r ]/.test(text[index])) return null
  return { name: text.slice(1, index), rawInput: text.slice(index) }
}

function describeCommand(definition, owner) {
  if (!definition || typeof definition !== 'object') return null
  const name = bounded(definition.name, 64).trim().toLowerCase()
  const handler = definition.handler
  if (!name || typeof handler !== 'function') return null
  if (!/^[a-z][a-z0-9_-]*$/.test(name)) return null
  const input = definition.input && typeof definition.input === 'object'
    ? {
      hint: bounded(definition.input.hint ?? '', 200),
      attachments: definition.input.attachments === true,
    }
    : null
  return {
    name,
    description: bounded(definition.description ?? '', 400),
    input,
    recordInput: definition.recordInput !== false,
    definitionId: bounded(definition.definitionId ?? '', 120),
    owner: owner || '',
    handler,
  }
}

function registerCommand(definition, owner = loadingOwner) {
  const entry = describeCommand(definition, owner)
  if (!entry) {
    pushLog('warn', `commands.register ignored: needs lowercase name + handler (${safeText(definition, 200)})`)
    return () => {}
  }
  const previous = commandEntries.get(entry.name)
  if (previous) pushLog('warn', `commands.register overrides /${entry.name}: ${previous.owner} -> ${entry.owner || '?'}`)
  commandEntries.set(entry.name, entry)
  pushLog('info', `commands.register /${entry.name} owner=${entry.owner || '?'} hint=${entry.input?.hint ?? '-'}`)
  try {
    ctx.emit('commands/change')
  } catch {
    // 事件总线没人听也不影响登记（上游也是 contained notification）
  }
  return () => {
    if (commandEntries.get(entry.name) === entry) {
      commandEntries.delete(entry.name)
      try {
        ctx.emit('commands/change')
      } catch {
        // 同上
      }
    }
  }
}

/** 列出可执行命令的**无 handler** 描述（原生只拿这个，不跨进程传函数）。 */
function commandDescriptors() {
  return [...commandEntries.values()]
    .sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    .map((entry) => ({
      name: entry.name,
      description: entry.description,
      hint: entry.input?.hint ?? '',
      attachments: entry.input?.attachments === true,
      owner: entry.owner,
    }))
}

const commandsService = {
  register(definition) {
    return registerCommand(definition)
  },
  list() {
    return commandDescriptors()
  },
  find(_agent, name) {
    const entry = commandEntries.get(String(name ?? ''))
    if (!entry) return undefined
    const { handler, ...view } = entry
    return view
  },
  /**
   * 解析并执行一行命令。语法/名字不认 → undefined（原生据此报「未注册」）；
   * handler 抛错 → `{kind:'error'}`（和上游一致：异常结算成 error 结果）。
   */
  async execute(agent, line, _submittedAttachments, signal) {
    const parsed = parseCommandText(line)
    if (!parsed) return undefined
    const entry = commandEntries.get(parsed.name)
    if (!entry) return undefined
    commandSeq += 1
    const commandId = `c${commandSeq}`
    const invocation = {
      commandId,
      agent,
      rawInput: parsed.rawInput,
      attachments: [],
      signal: signal ?? new AbortController().signal,
    }
    let result
    try {
      const value = await entry.handler(invocation)
      if (value && typeof value === 'object' && value.kind === 'success') {
        result = { kind: 'success', text: bounded(value.text ?? '', 4000) }
      } else if (value && typeof value === 'object' && value.kind === 'error') {
        result = { kind: 'error', text: bounded(value.text ?? '命令失败（未给原因）', 4000) }
      } else {
        result = { kind: 'error', text: '命令没有返回 {kind,text}' }
      }
    } catch (error) {
      result = { kind: 'error', text: bounded(safeText(error, 1200), 4000) }
    }
    sessionEvents.push(['command/run', { commandId, name: parsed.name, rawInput: parsed.rawInput }])
    sessionEvents.push(['command/done', { commandId, name: parsed.name, kind: result.kind }])
    if (sessionEvents.length > SESSION_EVENT_CAP) sessionEvents.splice(0, sessionEvents.length - SESSION_EVENT_CAP)
    return { commandId, name: parsed.name, result }
  },
  /** 附件回执解析器：原生这里不带附件提交，登记即返回空 disposer（不是假实现，是空集合）。 */
  registerFileReceiptResolver() {
    return () => {}
  },
}
ctx.provide('commands', commandsService)

const loadedPlugins = []
// 插件注册的提示词段/上下文：同样用「加载前后差集」认领，避免把 dsh 自己的
// harness 段（身份/persona）也端给原生侧 —— 那部分原生有自己的拼装。
const ownedSectionNames = new Set()
const ownedContextNames = new Set()
const registeredNames = (pick) =>
  new Set(ctx.systemPrompt.layers.merge(undefined, pick).keys())
for (const entry of await readPluginList()) {
  const specifier = typeof entry?.module === 'string' ? entry.module : ''
  if (!specifier) continue
  // 相对路径（./plugins/foo/index.js）相对于 data/ 解析；裸包（@deepseek-ai/...）仍从运行时解析。
  const target =
    specifier.startsWith('.') || specifier.startsWith('/')
      ? pathToFileURL(resolve(dataDir, specifier)).href
      : specifier
  // 工具归属：插件加载前后对比 tools.schemas()，差集就是这个插件注册的工具。
  const before = new Set(ctx.tools.schemas().map((schema) => schema.name))
  const beforeSections = registeredNames((layer) => layer.sections)
  const beforeContexts = registeredNames((layer) => layer.contexts)
  try {
    loadingOwner = specifier
    const mod = await import(target)
    await ctx.plugin(mod, entry.config ?? {})
    const added = ctx.tools.schemas().map((schema) => schema.name).filter((name) => !before.has(name))
    for (const name of registeredNames((layer) => layer.sections)) {
      if (!beforeSections.has(name)) ownedSectionNames.add(name)
    }
    for (const name of registeredNames((layer) => layer.contexts)) {
      if (!beforeContexts.has(name)) ownedContextNames.add(name)
    }
    // P3-b / P3-c：这个模块登记了哪些 provider / 命令（插件页与原生会话面用得到）。
    const llm = [...llmEntries.values()].filter((item) => item.owner === specifier).map((item) => item.id)
    const commandsOfPlugin = [...commandEntries.values()]
      .filter((item) => item.owner === specifier)
      .map((item) => item.name)
    loadedPlugins.push({ module: specifier, ok: true, tools: added, llm, commands: commandsOfPlugin })
  } catch (error) {
    // 加载失败：把这次登记了一半的 provider/命令收回（不然原生会看到一个永远发不出的通道）。
    for (const [key, item] of llmEntries) {
      if (item.owner === specifier) llmEntries.delete(key)
    }
    for (const [key, item] of commandEntries) {
      if (item.owner === specifier) commandEntries.delete(key)
    }
    loadedPlugins.push({ module: specifier, ok: false, error: safeText(error, 800), tools: [], llm: [], commands: [] })
    pushLog('error', `plugin load failed: ${specifier}: ${safeText(error, 800)}`)
  } finally {
    loadingOwner = ''
  }
}

const sessionEvents = []

/** 一次调用的最小 agent 门面：插件只会 append 事件，宿主不落盘、不重放。 */
function newAgent() {
  return {
    session: {
      append(type, data) {
        sessionEvents.push([type, data])
        if (sessionEvents.length > SESSION_EVENT_CAP) sessionEvents.shift()
      },
    },
  }
}

/** 模型可用的工具清单（只带 name/description/parameters，跟 tools.schemas() 同口径）。 */
function manifest() {
  const schemas = ctx.tools.schemas()
  return schemas.map((schema) => ({
    name: schema.name,
    description: schema.description ?? '',
    parameters: schema.parameters ?? { type: 'object', properties: {} },
  }))
}

/** 插件自己声明的渲染函数优先；没声明就退回 JSON 文本。 */
function renderResult(definition, args, value) {
  try {
    const blocks = definition.output?.render?.(args, value)
    if (Array.isArray(blocks)) {
      const text = blocks
        .filter((block) => block?.type === 'text' && typeof block.text === 'string')
        .map((block) => block.text)
        .join('\n')
      if (text) return text
    }
  } catch (error) {
    pushLog('warn', `render failed for ${definition.name}: ${safeText(error, 400)}`)
  }
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}

// 正在执行的调用：tool.cancel 按 id 找 controller（docs/187 §九 第 4 项）。
const activeCalls = new Map()
// 正在执行的斜杠命令（P3-c）：`command.cancel` 按 id abort。
const activeCommands = new Map()

async function invokeTool(msg, call) {
  const name = String(msg?.name ?? '')
  // executable() 才认条件注册；拿不到再退回 get()，避免把已注册工具误判成不存在。
  const definition = ctx.tools.executable(name) ?? ctx.tools.get(name)
  if (!definition) return { ok: false, error: `unknown tool: ${name}`, ms: 0 }
  const args = msg?.args ?? {}
  const timeoutMs = Number.isFinite(msg?.timeoutMs)
    ? Math.max(1000, Math.min(Number(msg.timeoutMs), 600000))
    : 60000
  const controller = call.controller
  let timer
  const started = Date.now()
  try {
    // 超时用 race 兑现：工具自己不理会 signal 时，调用方也必须按时拿到失败，
    // 而不是等它睡完（插件里的死循环/长 IO 不能把原生侧的审批流程焊住）。
    const value = await Promise.race([
      definition.execute(args, { agent: newAgent(), signal: controller.signal }),
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          call.timedOut = true
          controller.abort()
          reject(new Error(`tool timed out after ${timeoutMs}ms`))
        }, timeoutMs)
      }),
    ])
    return { ok: true, value, text: renderResult(definition, args, value), ms: Date.now() - started }
  } catch (error) {
    const cancelled = call.cancelled
    const timedOut = call.timedOut
    return {
      ok: false,
      cancelled,
      error: cancelled
        ? `tool cancelled after ${Date.now() - started}ms`
        : timedOut
          ? `tool timed out after ${timeoutMs}ms`
          : safeText(error, 2000),
      ms: Date.now() - started,
    }
  } finally {
    clearTimeout(timer)
  }
}

/**
 * 插件往系统提示里注册的段/上下文（`ctx.systemPrompt.section` / `.context`）。
 * 原生侧每次发起请求前拉一次，塞进 PromptPack 的拼装里 —— 段文本里的 `{{变量}}`
 * 由原生侧统一替换（和原生插件同一套口径）。
 *
 * 优先走内核的 `systemPrompt.assemble()`；但组装会向工具执行器要一段工具说明，
 * 而这个宿主没有装执行器（工具是原生侧直接调 `tool.invoke` 执行的，不经过 dsh
 * 的执行器），于是退化成**只读**地合并各作用域已注册的段 —— 不注册假服务、不改
 * 上游代码，只是把插件已经登记进去的东西读出来。
 */
async function assemblePrompt() {
  const service = ctx.systemPrompt
  const resolve = (value) => (typeof value === 'function' ? value({}) : value)
  const text = (value) => (typeof value === 'string' ? value : '')
  /** 只认领插件自己注册的段；dsh 的 harness 段由原生自己的拼装负责。 */
  const owned = (list, names) => list.filter((item) => names.has(item.name))
  try {
    const assembly = await service.assemble()
    return {
      source: 'assemble',
      sections: owned(
        (assembly?.sections ?? []).map((section) => ({
          name: section.name,
          text: text(section.text),
          interpolate: section.interpolate !== false,
        })),
        ownedSectionNames,
      ),
      contexts: owned(
        (assembly?.contexts ?? []).map((context) => ({
          name: context.name,
          text: text(context.text),
          interpolate: context.interpolate !== false,
        })),
        ownedContextNames,
      ),
      variables: Object.fromEntries(
        Object.entries(assembly?.variables ?? {}).filter(([, value]) => typeof value === 'string'),
      ),
    }
  } catch (error) {
    pushLog('warn', `prompt assemble fell back to registry read: ${safeText(error, 300)}`)
  }
  const mergedSections = service.layers.merge(undefined, (layer) => layer.sections)
  const mergedContexts = service.layers.merge(undefined, (layer) => layer.contexts)
  const sections = [...mergedSections.values()]
    .map((section) => ({
      name: section.name,
      order: Number.isFinite(section.order) ? section.order : 0,
      text: text(resolve(section.text)),
      interpolate: section.interpolate !== false,
    }))
    .filter((section) => ownedSectionNames.has(section.name))
    .sort((a, b) => a.order - b.order || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    .map(({ order, ...rest }) => rest)
  const contexts = [...mergedContexts.values()]
    .map((context) => ({
      name: context.name,
      order: Number.isFinite(context.order) ? context.order : 0,
      text: text(resolve(context.text)),
      interpolate: context.interpolate !== false,
    }))
    .filter((context) => ownedContextNames.has(context.name))
    .sort((a, b) => a.order - b.order || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    .map(({ order, ...rest }) => rest)
  return { source: 'registry', sections, contexts, variables: {} }
}

function helloFrame() {
  return {
    op: 'host.hello',
    pid: process.pid,
    version: process.version,
    bootMs: Date.now() - processStart,
    headless: true,
    tools: manifest(),
    plugins: loadedPlugins,
    // P3-b / P3-c：插件登记的模型供应商与斜杠命令（原生启动后就不再要一次 manifest）。
    llm: llmService.list(),
    commands: commandDescriptors(),
    logs: logs.slice(-40),
  }
}

/** 常数时间比较 token（长度不同直接 false）。 */
function tokenMatches(provided) {
  const a = Buffer.from(String(provided ?? ''), 'utf8')
  const b = Buffer.from(expectedToken, 'utf8')
  return a.length === b.length && timingSafeEqual(a, b)
}

const server = createServer((req, res) => {
  res.statusCode = 404
  res.end('not found')
})

const wss = new WebSocketServer({ server })

wss.on('connection', (ws, req) => {
  // 鉴权必须在 hello 之前：本机任意 App 都能连 127.0.0.1，没有 token 一律关连接。
  let provided = ''
  try {
    provided = new URL(req?.url ?? '/', 'http://127.0.0.1').searchParams.get('token') ?? ''
  } catch {
    provided = ''
  }
  if (!tokenMatches(provided)) {
    pushLog('warn', 'ws connection rejected: bad token')
    ws.close(4401, 'unauthorized')
    return
  }
  clients.add(ws)
  ws.send(JSON.stringify(helloFrame()))
  ws.on('close', () => clients.delete(ws))
  ws.on('message', async (raw) => {
    let msg
    try {
      msg = JSON.parse(raw.toString())
    } catch {
      return
    }
    if (msg?.op === 'tool.invoke') {
      const id = String(msg?.id ?? '')
      const call = { id, controller: new AbortController(), started: Date.now(), cancelled: false, timedOut: false }
      activeCalls.set(id, call)
      try {
        const result = await invokeTool(msg, call)
        // 已取消的调用不再回 tool.result（原生侧 pending 已移除）；tool.cancelled 已经发过。
        if (!call.cancelled && ws.readyState === ws.OPEN) {
          const frame = {
            op: 'tool.result',
            id: msg.id,
            ok: result.ok,
            value: result.value,
            text: result.text,
            error: result.error,
            ms: result.ms,
            sessionEvents: sessionEvents.length,
          }
          ws.send(JSON.stringify(frame))
        }
      } finally {
        activeCalls.delete(id)
      }
    } else if (msg?.op === 'tool.cancel') {
      const id = String(msg?.id ?? '')
      const call = activeCalls.get(id)
      if (call) {
        call.cancelled = true
        call.controller.abort()
      }
      if (ws.readyState === ws.OPEN) {
        ws.send(
          JSON.stringify({
            op: 'tool.cancelled',
            id,
            ms: call ? Date.now() - call.started : 0,
            active: Boolean(call),
          }),
        )
      }
    } else if (msg?.op === 'prompt.assemble') {
      try {
        const payload = await assemblePrompt()
        if (ws.readyState === ws.OPEN) {
          ws.send(JSON.stringify({ op: 'prompt.result', id: msg.id, ok: true, ...payload }))
        }
      } catch (error) {
        if (ws.readyState === ws.OPEN) {
          ws.send(
            JSON.stringify({ op: 'prompt.result', id: msg.id, ok: false, error: safeText(error, 800) }),
          )
        }
      }
    } else if (msg?.op === 'host.manifest') {
      if (ws.readyState === ws.OPEN) {
        ws.send(
          JSON.stringify({
            op: 'host.manifest',
            id: msg.id,
            tools: manifest(),
            plugins: loadedPlugins,
            llm: llmService.list(),
            commands: commandDescriptors(),
          }),
        )
      }
    } else if (msg?.op === 'llm.list') {
      // P3-b：原生随时可以重拉（插件页刷新/重新加载后），不依赖 hello。
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ op: 'llm.result', id: msg.id, ok: true, providers: llmService.list() }))
      }
    } else if (msg?.op === 'command.list') {
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ op: 'command.list.result', id: msg.id, ok: true, commands: commandDescriptors() }))
      }
    } else if (msg?.op === 'command.invoke') {
      const id = String(msg?.id ?? '')
      const controller = new AbortController()
      activeCommands.set(id, controller)
      const started = Date.now()
      const timeoutMs = Number.isFinite(msg?.timeoutMs)
        ? Math.max(1000, Math.min(Number(msg.timeoutMs), 120000))
        : 30000
      let timer
      try {
        const name = String(msg?.name ?? '')
        const rawInput = typeof msg?.rawInput === 'string' ? msg.rawInput : ''
        const line = `/${name}${rawInput}`
        // 超时/取消：handler 自己不看 signal 也必须按时返回失败，不能把原生 UI 焊住。
        const outcome = await Promise.race([
          commandsService.execute(newAgent(), line, [], controller.signal),
          new Promise((_, reject) => {
            timer = setTimeout(() => {
              controller.abort()
              reject(new Error(`command timed out after ${timeoutMs}ms`))
            }, timeoutMs)
          }),
        ])
        if (ws.readyState === ws.OPEN) {
          const ms = Date.now() - started
          if (!outcome) {
            ws.send(
              JSON.stringify({
                op: 'command.invoke.result',
                id: msg.id,
                ok: false,
                // kind 单独标 unknown：原生据此区分「命令没注册」和「命令执行失败」。
                kind: 'unknown',
                text: `命令未注册：/${name}`,
                error: `unknown command: ${name}`,
                ms,
              }),
            )
          } else {
            ws.send(
              JSON.stringify({
                op: 'command.invoke.result',
                id: msg.id,
                ok: outcome.result.kind === 'success',
                kind: outcome.result.kind,
                text: outcome.result.text,
                commandId: outcome.commandId,
                ms,
              }),
            )
          }
        }
      } catch (error) {
        if (ws.readyState === ws.OPEN) {
          ws.send(
            JSON.stringify({
              op: 'command.invoke.result',
              id: msg.id,
              ok: false,
              kind: 'error',
              text: safeText(error, 1200),
              error: safeText(error, 1200),
              ms: Date.now() - started,
            }),
          )
        }
      } finally {
        clearTimeout(timer)
        activeCommands.delete(id)
      }
    } else if (msg?.op === 'command.cancel') {
      const id = String(msg?.id ?? '')
      const controller = activeCommands.get(id)
      if (controller) controller.abort()
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ op: 'command.cancelled', id, active: Boolean(controller) }))
      }
    } else if (msg?.op === 'host.ping') {
      if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ op: 'host.pong', id: msg.id, at: Date.now() }))
    } else if (msg?.op === 'host.stop') {
      if (ws.readyState === ws.OPEN) {
        // 先 ack 再退：原生侧要能确认「它收到停止指令了」，而不是靠进程随机消失。
        ws.send(JSON.stringify({ op: 'host.ack', id: msg.id, at: Date.now() }))
        ws.send(JSON.stringify({ op: 'host.bye', at: Date.now() }))
      }
      ws.close()
      server.close()
      setTimeout(() => process.exit(0), 30)
    }
  })
})

server.listen(0, '127.0.0.1', () => {
  const bootMs = Date.now() - processStart
  // 原生侧只认这一行：端口必须由内核分配后回传，禁写死。
  console.log(`HOST_READY ${server.address().port} ${bootMs}`)
})
