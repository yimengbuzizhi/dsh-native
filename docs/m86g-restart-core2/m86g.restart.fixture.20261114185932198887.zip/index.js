export function apply(ctx) {
  ctx.llm.register({
    id: "m86g.restart.fixture.20261114185932198887.llm",
    label: 'M86-G UI 90s fixture',
    stream: function(request, emit) {
      var texts = [];
      (request.messages || []).forEach(function(message) {
        if (message.role !== 'user') return;
        (message.content || []).forEach(function(block) {
          if (block.type === 'text' && /^M86GUI_[A-Z0-9_]+$/.test(block.text || '')) texts.push(block.text);
        });
      });
      var latest = texts.length ? texts[texts.length - 1] : '';
      if (!latest) throw new Error('M86-G fixture input required');
      emit(/_HOLD$/.test(latest) ? 'M86GUI_PARTIAL' : 'M86GUI_REPLY_' + latest);
      if (/_HOLD$/.test(latest)) {
        return new Promise(function(resolve) {
          setTimeout(function() { resolve({stopReason: 'end_turn', usage: {input: 0, output: 2}}); }, 90000);
        });
      }
      return {stopReason: 'end_turn', usage: {input: 0, output: 2}};
    }
  });
}
