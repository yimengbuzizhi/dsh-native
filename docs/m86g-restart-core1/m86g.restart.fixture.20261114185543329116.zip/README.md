M86-G disposable acceptance fixture. Disable after use; retain data.
